import 'package:flutter/material.dart';

import 'generate_qr_page.dart';
import 'home_page.dart';
import 'login_page.dart';
import 'scan_qr_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'QR Auth App',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginPage(),
        '/home': (context) => const HomePage(),
        '/generate': (context) => const GenerateQrPage(),
        '/scan': (context) => const ScanQrPage(),
      },
    );
  }
}
