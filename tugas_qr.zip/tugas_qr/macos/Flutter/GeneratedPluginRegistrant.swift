//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import mobile_scanner

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  MobileScannerPlugin.register(with: registry.registrar(forPlugin: "MobileScannerPlugin"))
}
